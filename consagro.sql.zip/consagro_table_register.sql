
-- --------------------------------------------------------

--
-- Struktur dari tabel `register`
--

CREATE TABLE `register` (
  `username` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `register`
--

INSERT INTO `register` (`username`, `name`, `password`) VALUES
('anang1', 'anang1', 'anang'),
('anang', 'anang', '123'),
('', '', ''),
('', '', ''),
('', '', ''),
('ipin', 'ipin', 'ipin');
