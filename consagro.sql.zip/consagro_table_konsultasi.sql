
-- --------------------------------------------------------

--
-- Struktur dari tabel `konsultasi`
--

CREATE TABLE `konsultasi` (
  `id` int(200) NOT NULL,
  `nama_petani` varchar(100) NOT NULL,
  `alamat_petani` varchar(300) NOT NULL,
  `jenis_tanaman` varchar(300) NOT NULL,
  `penyakit_tanaman` varchar(1000) NOT NULL,
  `lokasi_pertanian` varchar(300) NOT NULL,
  `catatan_tambahan` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `konsultasi`
--

INSERT INTO `konsultasi` (`id`, `nama_petani`, `alamat_petani`, `jenis_tanaman`, `penyakit_tanaman`, `lokasi_pertanian`, `catatan_tambahan`) VALUES
(1123, 'qqweegjhjvkvbj, ', 'qwer', 'qwert', 'qwert', 'weert', 'qwert');
